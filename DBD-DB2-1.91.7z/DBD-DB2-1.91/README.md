# perl_DBD-DB2
Repository for DBD::DB2 perl.
dlls for ActivePerl and Strawberry Perl i.e. 
Perl On Windows is using the particular version of MingGW gcc compiler,
which is throwing the compilation error for sqlext.h which is bundled
in our CLI Driver. Hence uploading the precompiled DBD::DB2 dll's in "Windows_Binary" folder.



## pre-requisites

  The minimum perl version supported by driver is perl 5.8 and the latest version supported is perl 5.30.
